jQuery(function($) {
 $(".testimonial_star").starRating({
    totalStars: 5,
    strokeWidth: 0,
    starShape: 'rounded', //straight
    starSize: 22,
    readOnly: true,
    emptyColor: '#D8D8D8',
    activeColor: '#ffb31c',
    useGradient: false
  });
});